Locales["fr"] = {
    ["skin_menu"] = "menu de Skin",
    ["use_rotate_view"] = "utilisez Q et E pour tourner la vue.",
    ["skin"] = "changer de skin",
    ["saveskin"] = "sauvegarder skin dans un fichier",
}
