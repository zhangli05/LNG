Locales["zh-cn"] = {
    ["skin_menu"] = "皮肤选单",
    ["use_rotate_view"] = "使用 Q 和 E 旋转镜头视角.",
    ["skin"] = "更换皮肤数据",
    ["saveskin"] = "保存皮肤数据",
}
