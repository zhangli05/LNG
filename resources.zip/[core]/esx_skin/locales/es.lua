Locales["es"] = {
    ["skin_menu"] = "Menú de apariencia",
    ["use_rotate_view"] = "Utiliza Q y E para rotar la vista.",
    ["skin"] = "Cambiar aspecto",
    ["saveskin"] = "Guarda tu aspecto actual",
}
