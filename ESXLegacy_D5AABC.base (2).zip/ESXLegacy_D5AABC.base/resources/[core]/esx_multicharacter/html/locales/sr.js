const translate = new Object();

translate.name = "Ime";
translate.job = "Posao";
translate.bank = "Banka";
translate.money = "Novac";
translate.gender = "Pol";
translate.dob = "Datum rodjenja";
