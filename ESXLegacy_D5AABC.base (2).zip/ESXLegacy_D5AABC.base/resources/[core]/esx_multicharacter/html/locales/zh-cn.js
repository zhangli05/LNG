const translate = new Object();

translate.name = "我的姓名";
translate.job = "我的职业";
translate.bank = "银行存款";
translate.money = "手持现金";
translate.gender = "我的性别";
translate.dob = "出生日期";