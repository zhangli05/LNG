Locales["hu"] = {
    ["skin_menu"] = "Kinézet Menü",
    ["use_rotate_view"] = "Használd Q vagy E gombokat a forgatáshoz",
    ["skin"] = "kinézet változtatása",
    ["saveskin"] = "kinézet mentése fájlba",
}
