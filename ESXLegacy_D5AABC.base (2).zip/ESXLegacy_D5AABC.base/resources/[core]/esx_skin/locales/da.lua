Locales["da"] = {
    ["skin_menu"] = "Udseende Menu",
    ["use_rotate_view"] = "brug Q og E for at dreje kameraet.",
    ["skin"] = "skift udseende",
    ["saveskin"] = "gem udseende til en fil",
}
