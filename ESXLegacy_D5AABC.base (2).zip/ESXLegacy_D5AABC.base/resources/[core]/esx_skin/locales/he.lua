Locales["he"] = {
    ["skin_menu"] = "תפריט עור",
    ["use_rotate_view"] = "השתמש Q ו E כדי לסובב את התצוגה.",
    ["skin"] = "שנה עור",
    ["saveskin"] = "שמור עור לקובץ",
}
