Locales["sv"] = {
    ["skin_menu"] = "Skin Meny",
    ["use_rotate_view"] = "Använd Q och E för att rotera.",
    ["skin"] = "Ända utseende",
    ["saveskin"] = "Spara",
}
