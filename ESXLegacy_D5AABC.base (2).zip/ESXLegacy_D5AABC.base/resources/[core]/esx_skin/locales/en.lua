Locales["en"] = {
    ["skin_menu"] = "Skin Menu",
    ["use_rotate_view"] = "use Q and E to rotate the view.",
    ["skin"] = "change skin",
    ["saveskin"] = "save skin to a file",
}
