INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES
	('cannabis', 'Onvewerkte Wiet', 3, 0, 1),
	('marijuana', 'Wiet', 2, 0, 1)
;

INSERT INTO `licenses` (`type`, `label`) VALUES
	('weed_processing', 'Wiet Verwerkings vergunning')
;
