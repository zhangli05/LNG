Locales['sv'] = {
    ['valid_purchase'] = 'Vill du köpa detta?',
    ['yes'] = 'Ja',
    ['no'] = 'Nej',
    ['not_enough_money'] = 'Du har inte tillräckligt med pengar',
    ['press_access'] = 'Tryck [E] för att öppna menyn.',
    ['barber_blip'] = 'Frisören',
    ['you_paid'] = 'Du betalade %skr',
  }
