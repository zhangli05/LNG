Locales['sl'] = {
  ['valid_purchase'] = 'Prosimo potrdite nakup?',
  ['yes'] = 'Da',
  ['no'] = 'Ne',
  ['not_enough_money'] = 'Vi nimate dovolj denarja!',
  ['press_access'] = 'Pritisnite [E] da odprete Frizerski Salon.',
  ['barber_blip'] = 'Frizerski Salon',
  ['you_paid'] = 'Vi ste plačali $%s',
}
