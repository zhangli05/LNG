Locales['nl'] = {
  ['valid_purchase'] = 'aankoop bevestigen ?',
  ['yes'] = 'ja',
  ['no'] = 'nee',
  ['not_enough_money'] = 'je hebt niet genoeg geld',
  ['press_access'] = 'druk op [E] om een kapsel te kiezen.',
  ['barber_blip'] = 'Kapper',
  ['you_paid'] = 'Je hebt €%s betaald',
}
