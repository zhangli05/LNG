Locales['hu'] = {
  ['valid_purchase'] = 'Biztosan kifizeted?',
  ['yes'] = 'Igen',
  ['no'] = 'Nem',
  ['not_enough_money'] = 'Nincsen elég pénzed',
  ['press_access'] = 'Nyomj [E] hogy megnyisd a Fodrászatot.',
  ['barber_blip'] = 'Fodrászat',
  ['you_paid'] = 'Fizettél $%s',
}
