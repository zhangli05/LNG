Locales['tr'] = {
  ['valid_this_purchase'] = 'Değişiklikleri onaylıyor musun?',
  ['yes'] = 'Evet',
  ['no'] = 'Hayır',
  ['not_enough_money'] = 'Yeterli paran yok',
  ['press_menu'] = 'Kıyafet Mağazasına erişmek için ~b~[E]~s~ tuşuna bas.',
  ['clothes'] = 'Kıyafet Mağazası',
  ['you_paid'] = 'Ödeme yaptın: $%s',
  ['save_in_dressing'] = 'Kıyafeti dolabınıza kaydetmek ister misin?',
  ['name_outfit'] = 'Kıyafete bir isim ver',
  ['saved_outfit'] = 'Kıyafet kaydedildi!',
  ['outfit_name'] = 'Kıyafet İsmi',
  ['outfit_placeholder'] = 'Kıyafetine bir isim koy',
  ['confirm'] = 'Onayla'
}