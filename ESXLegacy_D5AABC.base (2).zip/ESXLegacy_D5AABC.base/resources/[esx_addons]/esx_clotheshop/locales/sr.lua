Locales['sr'] = {
  ['valid_this_purchase'] = 'Potvrdite kupovinu?',
  ['yes'] = 'Da',
  ['no'] = 'Ne',
  ['not_enough_money'] = 'Nemate dovoljno novca',
  ['press_menu'] = 'Pritisnite [E] da pristupite butiku odeće.',
  ['clothes'] = 'Butik Odeće',
  ['you_paid'] = 'Platili ste $%s',
  ['save_in_dressing'] = 'Da li želite da sačuvate odeću u svojoj kući?',
  ['name_outfit'] = 'Unesite ime outfita',
  ['saved_outfit'] = 'Outfit je sačuvan!',
}
