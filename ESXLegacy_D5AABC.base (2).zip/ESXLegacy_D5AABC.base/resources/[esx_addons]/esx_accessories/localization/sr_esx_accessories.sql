
INSERT INTO `datastore` (name, label, shared) VALUES
	('user_ears', 'Uši', 0),
	('user_glasses', 'Naočare', 0),
	('user_helmet', 'Kaciga', 0),
	('user_mask', 'Maska', 0)
;
