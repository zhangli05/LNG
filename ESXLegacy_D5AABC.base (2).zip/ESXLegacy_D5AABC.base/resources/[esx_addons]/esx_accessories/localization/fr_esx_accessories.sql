INSERT INTO `datastore` (name, label, shared) VALUES
    ('user_ears', 'Oreilles', 0),
    ('user_glasses', 'Lunettes', 0),
    ('user_helmet', 'Casque', 0),
    ('user_mask', 'Masque', 0)
;
