INSERT INTO `datastore` (name, label, shared) VALUES
	('user_ears', 'Kulaklık', 0),
	('user_glasses', 'Gözlük', 0),
	('user_helmet', 'Kask', 0),
	('user_mask', 'Maske', 0)
;