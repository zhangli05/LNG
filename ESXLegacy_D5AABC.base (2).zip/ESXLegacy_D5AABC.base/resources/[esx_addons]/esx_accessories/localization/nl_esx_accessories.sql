INSERT INTO `datastore` (name, label, shared) VALUES
	('user_ears', 'Oor Accessoires', 0),
	('user_glasses', 'Bril', 0),
	('user_helmet', 'Hoofddeksel', 0),
	('user_mask', 'Masker', 0)
;
