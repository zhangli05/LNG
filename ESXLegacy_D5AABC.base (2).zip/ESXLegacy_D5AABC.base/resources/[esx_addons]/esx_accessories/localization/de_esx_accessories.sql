INSERT INTO `datastore` (name, label, shared) VALUES
	('user_ears', 'Ohr', 0),
	('user_glasses', 'Brille', 0),
	('user_helmet', 'Helm', 0),
	('user_mask', 'Maske', 0)
;
