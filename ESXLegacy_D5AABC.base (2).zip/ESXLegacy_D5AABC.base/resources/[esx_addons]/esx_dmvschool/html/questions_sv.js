var tableauQuestion = [
	{
		question: "Om du ligger i 80 km/h, och kommer in i ett bostadsområde måste du:",
		propositionA: "Du accelererar",
		propositionB: "Du behåller din hastighet, om du inte passerar andra fordon",
		propositionC: "Du saktar ner",
		propositionD: "Du behåller hastigheten",
		reponse: "C"
	},

	{
		question: "Om du svänger höger vid ett trafikljus, men ser en fotgängare gå över vägen. Vad gör du?:",
		propositionA: "Du passerar fotgängaren",
		propositionB: "Du ser omkring dig att det inte finns några andra fordon i närheten",
		propositionC: "Du väntar tills fotgängaren passerat",
		propositionD: "Du skjuter fotgängaren och kör över han",
		reponse: "C"
	},

	{
		question: "Utan någon förhandsindikation, hastigheten i ett bostadsområde är: __ km/h",
		propositionA: "30 km/h",
		propositionB: "50 km/h",
		propositionC: "40 km/h",
		propositionD: "60 km/h",
		reponse: "B"
	},

	{
		question: "Innan varje filbyte måste du:",
		propositionA: "Kolla dina speglar",
		propositionB: "Kontrollera dina döda vinklar",
		propositionC: "Signalera dina avsikter",
		propositionD: "Alla uppskrivna",
		reponse: "D"
	},

	{
		question: "Vilken alkoholhalt i blodet klassas som rattfylleri?",
		propositionA: "0.05%",
		propositionB: "0.18%",
		propositionC: "0.08%",
		propositionD: "0.06%",
		reponse: "C"
	},

	{
		question: "När kan du fortsätta att köra vid ett trafikljus?",
		propositionA: "När det är grönt",
		propositionB: "När det inte finns någon i korsningen",
		propositionC: "Du befinner dig i en skolzon",
		propositionD: "När det är grönt och / eller rött och du svänger höger",
		reponse: "D"
	},

	{
		question: "En fotgängare har inte en grön gubbe lysandes, men går ändå. Vad gör du?",
		propositionA: "Du låter de passera",
		propositionB: "Du observerar innan du fortsätter",
		propositionC: "Du vinkar för att säga åt dem att gå över",
		propositionD: "Du fortsätter eftersom ditt trafikljus är grönt",
		reponse: "D"
	},

	{
		question: "Vad är tillåtet när man passerar ett annat fordon?",
		propositionA: "Du följer den noga för att passera den snabbare",
		propositionB: "Du passerar den utan att lämna vägbanan",
		propositionC: "Du kör på motsatt sida av vägen för att passera",
		propositionD: "Du överskrider hastighetsgränsen för att passera dem",
		reponse: "C"
	},

	{
		question: "Du kör på en motorväg som anger en maxhastighet på 120 km/h. Men de flesta trafikanter kör i 125 km/h, så du ska inte köra fortare än:",
		propositionA: "120 km/h",
		propositionB: "125 km/h",
		propositionC: "130 km/h",
		propositionD: "110 km/h",
		reponse: "A"
	},

	{
		question: "När du blir omkörd av ett annat fordon är det viktigt att INTE göra det:",
		propositionA: "Sakta ned",
		propositionB: "Kolla dina backspeglar",
		propositionC: "Titta på andra förare",
		propositionD: "Öka din hastighet",
		reponse: "D"
	},
]
