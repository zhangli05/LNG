var tableauQuestion = [
	{
		question: "Je rijd 80 km/u maar je nadert een woonwijk, wat doe je ?:",
		propositionA: "Je geeft gas bij",
		propositionB: "Je behoudt je snelheid, zo lang je niemand inhaalt",
		propositionC: "Je behoudt je snelheid",
		propositionD: "Je remt af",
		reponse: "D"
	},

	{
		question: "Je gaat rechts bij een stoplicht maar je ziet iemand oversteken, wat doe je ?:",
		propositionA: "Je wacht totdat de voetganger is overgestoken",
		propositionB: "Je passeert de voetganger",
		propositionC: "Je kijkt of er geen voertuigen om je heen zijn",
		propositionD: "Je rijdt de voetganger aan en maakt dat je weg komt",
		reponse: "A"
	},

	{
		question: "Zonder enige indicatie, de snelheid in een woonwijk is: __ km/h",
		propositionA: "30 km/u",
		propositionB: "50 km/u",
		propositionC: "40 km/u",
		propositionD: "60 km/u",
		reponse: "A"
	},

	{
		question: "Voordat je van rijstrook veranderd moet je:",
		propositionA: "Kijken in je spiegels",
		propositionB: "Kijken in je blinde hoek",
		propositionC: "Gebruik je knipperlicht naar de correcte rijbaan",
		propositionD: "Alles hierboven",
		reponse: "D"
	},

	{
		question: "Welk alcoholgehalte word gezien als rijden onder invloed?",
		propositionA: "0.05%",
		propositionB: "0.18%",
		propositionC: "0.08%",
		propositionD: "0.06%",
		reponse: "C"
	},

	{
		question: "Wanneer kan je doorrijden bij een verkeerslicht?",
		propositionA: "Wanneer het groen is",
		propositionB: "Wanneer er niemand bij het kruispunt is",
		propositionC: "Als je in een school zone bent",
		propositionD: "Als je boven de 100km/u rijdt.",
		reponse: "A"
	},

	{
		question: "Een voetganger heeft een rood licht om over te steken, wat doe je ?",
		propositionA: "Je laat diegene passeren",
		propositionB: "Je observeert wat diegene doet en gaat vervolgens door omdat het groen is.",
		propositionC: "Je signaleert diegene om over te steken",
		propositionD: "Je gaat door want je hebt groen licht.",
		reponse: "D"
	},

	{
		question: "Wat is toegestaan als je een voertuig inhaalt",
		propositionA: "Je gaat bumper kleven om sneller voorbij te gaan",
		propositionB: "Je passeert zonder de weg te verlaten",
		propositionC: "Je rijdt aan de andere kant van de weg om in te halen",
		propositionD: "Je gaat te snel rijden.",
		reponse: "C"
	},

	{
		question: "Je rijdt op de snelweg wat een maxiumum snelheid van 120 km/u hanteert maar iedereen rijdt gemiddeld 125 km/u, hoe hard mag je maximaal gaan:",
		propositionA: "120 km/u",
		propositionB: "125 km/u",
		propositionC: "130 km/u",
		propositionD: "110 km/u",
		reponse: "A"
	},

	{
		question: "Wat moet je NIET doen als je word ingehaald door een ander voertuig:",
		propositionA: "Verslomen",
		propositionB: "Je spiegels bekijken",
		propositionC: "Andere bestuurders bekijken",
		propositionD: "Snelheid verhogen",
		reponse: "D"
	},
]
