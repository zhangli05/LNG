
var tableauQuestion = [
	{
		question: "Ako vozite 80 km/h i prilazite naseljenom mestu, vi ćete:",
		propositionA: "Dodati gas i ubrzati",
		propositionB: "Nastaviti voziti 80 km/h, ako ne pretičete",
		propositionC: "Usporiti",
		propositionD: "Zadržati brzinu od 80 km/h",
		reponse: "C"
	},

	{
		question: "Ako skrećete desno na semafor i vidite pešaka koji prelazi pešački prelaz, vi ćete:",
		propositionA: "Proći pored pešaka",
		propositionB: "Pogledati da li ima vozila",
		propositionC: "Sačekati da pešak pređe put",
		propositionD: "Udariti pešaka i nastaviti voziti",
		reponse: "C"
	},

	{
		question: "Bez ikakvog znaka, ograničenje brzine u naseljenom mestu je: __ km/h",
		propositionA: "30 km/h",
		propositionB: "50 km/h",
		propositionC: "40 km/h",
		propositionD: "60 km/h",
		reponse: "B"
	},

	{
		question: "Pre svakog prestrojavanja, vi morate:",
		propositionA: "Pogledati retrovizore",
		propositionB: "Proveriti mrtve uglove",
		propositionC: "Signalizirati vaše namere",
		propositionD: "Sve od navedenog",
		reponse: "D"
	},

	{
		question: "Koji nivo alkohola u krvi je dozvoljen dok vozite?",
		propositionA: "0.05%",
		propositionB: "0.18%",
		propositionC: "0.08%",
		propositionD: "0.06%",
		reponse: "C"
	},

	{
		question: "Kada možete nastaviti voziti na semaforu?",
		propositionA: "Kada je zeleno svetlo",
		propositionB: "Kada nema nikoga na raskrsnici",
		propositionC: "Kada ste u zoni škole",
		propositionD: "Kada je zeleno i/ili vi skrećete desno",
		reponse: "D"
	},

	{
		question: "Pešak stoji na semaforu i njemu je crveno za pešake, šta ćete učiniti?",
		propositionA: "Pustiti ga da pređe",
		propositionB: "Gledati dobro pre nego što prođete",
		propositionC: "Pokazati mu da pređe put",
		propositionD: "Nastaviti normalno jer je vama zeleno svetlo",
		reponse: "D"
	},

	{
		question: "Šta je dozvoljeno kada pretičete vozilo?",
		propositionA: "Približavanje preblizu vozila da bi ga brže pretekli",
		propositionB: "Preticanje bez napuštanja trake",
		propositionC: "Vožnja suprotnim smerom dok pretičete",
		propositionD: "Prekoračenje brzine dok pretičete",
		reponse: "C"
	},

	{
		question: "Vozite se autoputem gde je ograničenje 130 km/h, ali svi oko vas voze brže od vas, koliko smete voziti?",
		propositionA: "130 km/h",
		propositionB: "145 km/h",
		propositionC: "120 km/h",
		propositionD: "135 km/h",
		reponse: "A"
	},

	{
		question: "Kada vas pretiče drugo vozilo, ne smete uraditi sledeće:",
		propositionA: "Usporiti",
		propositionB: "Proveriti retrovizore",
		propositionC: "Gledati ostale vozače",
		propositionD: "Povećati brzinu",
		reponse: "D"
	},
]
