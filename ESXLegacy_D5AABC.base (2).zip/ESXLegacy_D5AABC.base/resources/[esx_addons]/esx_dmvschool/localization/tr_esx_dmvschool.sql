INSERT INTO `licenses` (`type`, `label`) VALUES
	('dmv', 'Sürücü Belgesi'),
	('drive', 'Sürücü Ehliyeti'),
	('drive_bike', 'Motosiklet Ehliyeti'),
	('drive_truck', ' Ticari Sürücü Ehliyeti')
;