INSERT INTO `licenses` (`type`, `label`) VALUES
	('dmv', 'Theorie examen'),
	('drive', 'Rijbewijs B'),
        ('drive_bike', 'Rijbewijs A'),
	('drive_truck', 'Rijbewijs C')
;
