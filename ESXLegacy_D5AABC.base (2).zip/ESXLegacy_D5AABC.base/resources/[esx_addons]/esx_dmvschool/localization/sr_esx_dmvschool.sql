INSERT INTO `licenses` (`type`, `label`) VALUES
	('dmv', 'Vozačka dozvola'),
	('drive', 'Vozačka dozvola'),
	('drive_bike', 'Dozvola za motor'),
	('drive_truck', 'Komercijalna vozačka dozvola')
;
