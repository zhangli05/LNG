INSERT INTO `licenses` (`type`, `label`) VALUES
	('dmv', 'Führerscheun'),
	('drive', 'Autoführerschein'),
	('drive_bike', 'Motorradführerschein'),
	('drive_truck', 'LKW Führerschein')
;
