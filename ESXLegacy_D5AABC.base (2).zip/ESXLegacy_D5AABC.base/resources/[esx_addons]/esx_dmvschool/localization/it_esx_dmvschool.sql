INSERT INTO `licenses` (`type`, `label`) VALUES
	('dmv', 'Foglio Rosa'),
	('drive', 'Patente Auto'),
	('drive_bike', 'Patente Moto'),
	('drive_truck', 'Patente Camion')
;
