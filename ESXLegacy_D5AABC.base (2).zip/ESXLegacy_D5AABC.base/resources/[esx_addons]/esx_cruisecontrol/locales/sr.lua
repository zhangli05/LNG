Locales['sr'] = {
  ['activated']   = 'Tempomat je aktiviran',
  ['deactivated'] = 'Tempomat je deaktiviran',
  ['increaseSpeed'] = 'Povećaj Brzinu',
  ['decreaseSpeed'] = 'Smanji Brzinu',
  ['cruiseControl'] = 'Tempomat',

  --Seatbelt
  ['toggleSeatbelt'] = "Toggle Seatbelt",
  ["seatbeltOn"] = "Seatbelt ON",
  ["seatbeltOff"] = "Seatbelt OFF"
}
