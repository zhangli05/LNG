Locales['en'] = {
  ['activated']   = 'Cruise control activated',
  ['deactivated'] = 'Cruise control deactivated',
  ['increaseSpeed'] = 'Increase Speed',
  ['decreaseSpeed'] = 'Decrease Speed',
  ['cruiseControl'] = 'Cruise Control',

  --Seatbelt
  ['toggleSeatbelt'] = "Toggle Seatbelt",
  ["seatbeltOn"] = "Seatbelt ON",
  ["seatbeltOff"] = "Seatbelt OFF"
}
