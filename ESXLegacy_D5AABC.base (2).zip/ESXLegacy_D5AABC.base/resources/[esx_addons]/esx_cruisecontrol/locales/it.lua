Locales['it'] = {
  ['activated']   = 'Cruise Control attivato',
  ['deactivated'] = 'Cruise Control disattivato',
  ['increaseSpeed'] = 'Aumenta la velocità',
  ['decreaseSpeed'] = 'Diminuisci la velocità',
  ['cruiseControl'] = 'Cruise Control',

  --Seatbelt
  ['toggleSeatbelt'] = "Attiva/Disattiva la cintura di sicurezza",
  ['seatbeltOn'] = "Cintura di sicurezza INSERITA",
  ['seatbeltOff'] = "Cintura di sicurezza TOLTA"
}
