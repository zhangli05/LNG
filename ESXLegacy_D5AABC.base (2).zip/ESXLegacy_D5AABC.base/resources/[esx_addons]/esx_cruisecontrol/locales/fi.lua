Locales['fi'] = {
  ['activated']   = 'Aktivoitu',
  ['deactivated'] = 'Deaktivoitu',
  ['increaseSpeed'] = 'Nosta nopeutta',
  ['decreaseSpeed'] = 'Laske nopeutta',
  ['cruiseControl'] = 'Vakionopeudensäädin',

  --Seatbelt
  ['toggleSeatbelt'] = "Toggle Seatbelt",
  ["seatbeltOn"] = "Seatbelt ON",
  ["seatbeltOff"] = "Seatbelt OFF"
}
