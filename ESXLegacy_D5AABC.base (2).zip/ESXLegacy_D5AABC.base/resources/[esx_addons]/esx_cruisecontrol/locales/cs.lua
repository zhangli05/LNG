Locales['cs'] = {
    ['activated']   = 'Tempomat byl aktivován',
    ['deactivated'] = 'Tempomat byl deaktivován',
    ['increaseSpeed'] = 'Zvýšit rychlost',
    ['decreaseSpeed'] = 'Znížit rychlost',
    ['cruiseControl'] = 'Tempomat',
  
    --Pás
    ['toggleSeatbelt'] = "Zapnout pás",
    ["seatbeltOn"] = "Zapásli jste se",
    ["seatbeltOff"] = "Odopásli jste se"
  }