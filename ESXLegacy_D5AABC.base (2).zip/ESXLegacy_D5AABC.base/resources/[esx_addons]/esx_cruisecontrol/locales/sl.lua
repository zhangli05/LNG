Locales['sl'] = {
  ['activated']   = 'Tempomat Vključen',
  ['deactivated'] = 'Tempomat Izključen',
  ['increaseSpeed'] = 'Povečajte hitrost',
  ['decreaseSpeed'] = 'Zmanjšajte hitrost',
  ['cruiseControl'] = 'Tempomat',

  --Seatbelt
  ['toggleSeatbelt'] = "Toggle Seatbelt",
  ["seatbeltOn"] = "Seatbelt ON",
  ["seatbeltOff"] = "Seatbelt OFF"
}