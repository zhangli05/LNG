INSERT INTO `licenses` (`type`, `label`) VALUES
    ('boat', 'Licenca za Čolne')
;
