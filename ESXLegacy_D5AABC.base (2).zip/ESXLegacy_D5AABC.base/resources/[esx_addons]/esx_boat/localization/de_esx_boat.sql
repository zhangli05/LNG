INSERT INTO `licenses` (`type`, `label`) VALUES
	('boat', 'Boot Schein')
;
