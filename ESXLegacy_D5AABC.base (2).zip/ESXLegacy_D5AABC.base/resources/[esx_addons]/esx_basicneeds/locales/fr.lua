Locales['fr'] = {
  ['used_food'] = 'Vous avez mangé 1x %s',
  ['used_drink'] = 'Vous avez bu 1x %s',
  ['got_healed'] = 'Vous avez été soigné.'
}
