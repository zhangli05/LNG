Locales['pl'] = {
  ['used_bread'] = 'zjadłeś/aś 1x chleb',
  ['used_water'] = 'wypiłeś/aś 1x woda',
}