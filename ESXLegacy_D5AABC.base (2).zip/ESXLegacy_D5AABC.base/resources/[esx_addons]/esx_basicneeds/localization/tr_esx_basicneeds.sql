INSERT INTO `items` (`name`, `label`, `weight`) VALUES
    ('bread', 'Ekmek', 1),
    ('water', 'Su', 1)
;
